#pragma once

#include <M5CoreS3.h>

#include <unordered_map>

#include "xiaomi_cybergear_driver.hpp"
// #include "cybergear_driver.hpp"
// #include "driver/twai.h"

#define POLLING_RATE_MS 1000

struct CybergearConfig
{
    uint8_t id;                 //!< motor id
    float limit_speed;          //!< limit speed (rad/s)
    float limit_current;        //!< limit current (A)
    float limit_torque;         //!< limit torque (Nm)
    float current_kp;           //!< control parameter kp for current control
    float current_ki;           //!< control parameter ki for current control
    float current_filter_gain;  //!< current filter gain
};

class RobotController {
private:
    static const char* TAG;  //!< tag
    uint8_t master_can_id_;  //!< master can id
    uint32_t display_cnt_;   //!< display count
    /*
     * CAN FUNCTIONS
     */
    esp_err_t init(gpio_num_t tx_gpio_num, gpio_num_t rx_gpio_num, uint32_t brp,
                   uint8_t tseg_1, uint8_t tseg_2, uint8_t sjw,
                   bool triple_sampling);
    esp_err_t transmitMessage(twai_message_t* message);
    esp_err_t receiveMessage(twai_message_t& message);

    /*
     * MOTOR FUNCTIONS - CybergearDriver -
     */

    XiaomiCyberGearDriver motor_driver_;
    // CybergearDriver motor_driver_;
    //  typedef std::unordered_map<uint8_t, CybergearDriver> CybergearDriverMap;
    typedef std::unordered_map<uint8_t, CybergearConfig> CybergearConfigMap;
    typedef std::unordered_map<uint8_t, MotorStatus> CybergearMotorStatusMap;
    //  CybergearDriverMap motor_drivers_;
    CybergearConfigMap motor_configs_;
    CybergearMotorStatusMap motor_status_;
    void initMotorConfigs();
    void initMotorDriver();
    void initMotorStatus();

public:
    RobotController();
    RobotController(uint8_t master_can_id);
    ~RobotController();

    void setCanvas(M5Canvas* canvas);
    M5Canvas* canvas_;

    /*
     * ROBOT FUNCTIONS
     */
    esp_err_t process_recv_can_packet();

    void getMotorStatus();

    /*
     * MOTOR FUNCTIONS - CybergearDriver -
     */
    void initTwai(uint8_t rx_pin, uint8_t tx_pin);
    void initMotor();

    void checkAlerts();
    void handle_rx_message(twai_message_t& message);

    esp_err_t sendCommand(uint8_t can_id, uint8_t cmd_id, uint16_t option,
                          uint8_t len, uint8_t send_data[]);
    esp_err_t changeMotorId(uint8_t motor_id, uint8_t next_motor_id);
    esp_err_t setMotorMode(uint8_t motor_id, uint8_t mode);

    esp_err_t receiveResponse(uint8_t cmd, uint8_t* data);

    /*
     * DISPLAY FUNCTIONS - M5CORE3 -
     */
    void displayStatus();
};