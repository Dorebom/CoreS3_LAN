#pragma once

#include <M5CoreS3.h>

#include "driver/twai.h"
#include "xiaomi_cybergear_defs.hpp"

/**
 * @brief MotorStatus class
 */
struct MotorStatus
{
    uint8_t master_can_id_;    //!< master can id
    uint8_t motor_can_id;      //!< motor id
    float position;            //!< encoder position (-4pi to 4pi)
    float velocity;            //!< motor velocity (-30rad/s to 30rad/s)
    float effort;              //!< motor effort (-12Nm - 12Nm)
    float temperature;         //!< temperature
    uint16_t raw_position;     //!< raw position (for sync data)
    uint16_t raw_velocity;     //!< raw velocity (for sync data)
    uint16_t raw_effort;       //!< raw effort (for sync data)
    uint16_t raw_temperature;  //!< raw temperature (for sync data)
    MotorStatus()
        : position(0.0),
          velocity(0.0),
          effort(0.0),
          temperature(0.0),
          raw_position(0),
          raw_velocity(0),
          raw_effort(0),
          raw_temperature(0) {
    }
    bool updateStatus(unsigned long id, uint8_t* data) {
        // if id is not mine
        uint8_t receive_can_id = id & 0xff;
        if (receive_can_id != master_can_id_) {
            USBSerial.printf(
                "MotorStatus::updateStatus: receive_can_id != "
                "master_can_id_\n");
            return false;
        }

        uint8_t motor_can_id = (id & 0xff00) >> 8;
        if (motor_can_id != motor_can_id) {
            USBSerial.printf(
                "MotorStatus::updateStatus: motor_can_id != motor_can_id\n");
            return false;
        }
        // check packet type
        uint8_t packet_type = (id & 0x3F000000) >> 24;
        if (packet_type != CMD_RESPONSE) {
            USBSerial.printf(
                "MotorStatus::updateStatus: packet_type != CMD_RESPONSE\n");
            return false;
        }

        raw_position = (uint16_t)(data[1] | data[0] << 8);
        raw_velocity = (uint16_t)(data[3] | data[2] << 8);
        raw_effort = (uint16_t)(data[5] | data[4] << 8);
        raw_temperature = (uint16_t)(data[7] | data[6] << 8);

        position = uint_to_float(raw_position, P_MIN, P_MAX);
        velocity = uint_to_float(raw_velocity, V_MIN, V_MAX);
        effort = uint_to_float(raw_effort, T_MIN, T_MAX);
        temperature = raw_temperature;

        return true;
    }
    float uint_to_float(uint16_t x, float x_min, float x_max) {
        uint16_t type_max = 0xFFFF;
        float span = x_max - x_min;
        return (float)x / type_max * span + x_min;
    }
    void setMasterCanId(uint8_t master_can_id) {
        master_can_id_ = master_can_id;
    }
    void setMotorCanId(uint8_t motor_id) {
        motor_can_id = motor_id;
    }
};

struct XiaomiCyberGearStatus
{
    float position;
    float speed;
    float torque;
    uint16_t temperature;
};

struct XiaomiCyberGearMotionCommand
{
    float position;
    float speed;
    float torque;
    float kp;
    float kd;
};

class XiaomiCyberGearDriver {
public:
    XiaomiCyberGearDriver();
    XiaomiCyberGearDriver(uint8_t master_can_id);
    XiaomiCyberGearDriver(uint8_t master_can_id, uint8_t cybergear_can_id);
    virtual ~XiaomiCyberGearDriver();

    /**
     * @retval -1 Error
     * @retval 0 OK
     */
    int init_twai(uint8_t rx_pin, uint8_t tx_pin, bool serial_debug = false);
    void init_motor(uint8_t motor_can_id, uint8_t mode);
    void enable_motor(uint8_t motor_can_id);
    void stop_motor(uint8_t motor_can_id);
    void set_run_mode(uint8_t motor_can_id, uint8_t mode);

    void set_limit_speed(uint8_t motor_can_id, float speed);
    void set_limit_current(uint8_t motor_can_id, float current);
    void set_limit_torque(uint8_t motor_can_id, float torque);

    // MODE MOTION
    void send_motion_control(uint8_t motor_can_id,
                             XiaomiCyberGearMotionCommand cmd);

    // MODE_CURRENT
    void set_current_kp(uint8_t motor_can_id, float kp);
    void set_current_ki(uint8_t motor_can_id, float ki);
    void set_current_filter_gain(uint8_t motor_can_id, float gain);
    void set_current_ref(uint8_t motor_can_id, float current);

    // MODE_POSITION
    void set_position_kp(uint8_t motor_can_id, float kp);
    void set_position_ref(uint8_t motor_can_id, float position);

    // MODE_SPEED
    void set_speed_kp(uint8_t motor_can_id, float kp);
    void set_speed_ki(uint8_t motor_can_id, float ki);
    void set_speed_ref(uint8_t motor_can_id, float speed);

    uint8_t get_run_mode() const;
    uint8_t get_motor_can_id(uint8_t motor_can_id) const;
    void set_motor_can_id(uint8_t motor_can_id, uint8_t next_can_id);

    void request_status(uint8_t motor_can_id);
    void process_message(twai_message_t& message);
    XiaomiCyberGearStatus get_status() const;

private:
    uint16_t _float_to_uint(float x, float x_min, float x_max, int bits);
    float _uint_to_float(uint16_t x, float x_min, float x_max);
    void _send_can_package(uint8_t can_id, uint8_t cmd_id, uint16_t option,
                           uint8_t len, uint8_t* data);
    void _send_can_float_package(uint8_t can_id, uint16_t addr, float value,
                                 float min, float max);

    uint8_t _cybergear_can_id;
    uint8_t _master_can_id;
    uint8_t _run_mode;
    bool _use_serial_debug;
    XiaomiCyberGearStatus _status;
};