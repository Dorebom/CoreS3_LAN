#pragma once

#include <stdint.h>

#include "cybergear_driver_defs.hpp"
#include "driver/twai.h"

/**
 * @brief MotorStatus class
 */
struct MotorStatus
{
    uint8_t master_can_id_;    //!< master can id
    uint8_t motor_can_id;      //!< motor id
    float position;            //!< encoder position (-4pi to 4pi)
    float velocity;            //!< motor velocity (-30rad/s to 30rad/s)
    float effort;              //!< motor effort (-12Nm - 12Nm)
    float temperature;         //!< temperature
    uint16_t raw_position;     //!< raw position (for sync data)
    uint16_t raw_velocity;     //!< raw velocity (for sync data)
    uint16_t raw_effort;       //!< raw effort (for sync data)
    uint16_t raw_temperature;  //!< raw temperature (for sync data)
    MotorStatus()
        : position(0.0),
          velocity(0.0),
          effort(0.0),
          temperature(0.0),
          raw_position(0),
          raw_velocity(0),
          raw_effort(0),
          raw_temperature(0) {
    }
    bool updateStatus(unsigned long id, uint8_t *data) {
        // if id is not mine
        uint8_t receive_can_id = id & 0xff;
        if (receive_can_id != master_can_id_) {
            return false;
        }

        uint8_t motor_can_id = (id & 0xff00) >> 8;
        if (motor_can_id != motor_can_id) {
            return false;
        }
        // check packet type
        uint8_t packet_type = (id & 0x3F000000) >> 24;
        if (packet_type != CMD_RESPONSE) {
            return false;
        }

        raw_position = (uint16_t)(data[1] | data[0] << 8);
        raw_velocity = (uint16_t)(data[3] | data[2] << 8);
        raw_effort = (uint16_t)(data[5] | data[4] << 8);
        raw_temperature = (uint16_t)(data[7] | data[6] << 8);

        position = uint_to_float(raw_position, P_MIN, P_MAX);
        velocity = uint_to_float(raw_velocity, V_MIN, V_MAX);
        effort = uint_to_float(raw_effort, T_MIN, T_MAX);
        temperature = raw_temperature;

        return true;
    }
    float uint_to_float(uint16_t x, float x_min, float x_max) {
        uint16_t type_max = 0xFFFF;
        float span = x_max - x_min;
        return (float)x / type_max * span + x_min;
    }
    void setMasterCanId(uint8_t master_can_id) {
        master_can_id_ = master_can_id;
    }
    void setMotorCanId(uint8_t motor_id) {
        motor_can_id = motor_id;
    }
};

/**
 * @brief Cybergear driver class
 */
class CybergearDriver {
public:
    /**
     * @brief Construct a new Cybergear Driver object
     */
    CybergearDriver();

    /**
     * @brief Construct a new Cybergear Driver object
     *
     * @param master_can_id   master can id
     */
    CybergearDriver(uint8_t master_can_id);

    /**
     * @brief Destroy the Cybergear Driver object
     */
    ~CybergearDriver();

    /**
     * @brief Initialize the Cybergear driver
     *
     * @param tx_gpio_num   TX GPIO number
     * @param rx_gpio_num   RX GPIO number
     * @param brp           Baud rate prescaler
     * @param tseg_1        Time segment 1
     * @param tseg_2        Time segment 2
     * @param sjw           Synchronization jump width
     * @param triple_sampling   Triple sampling
     * @return esp_err_t
     */
    esp_err_t init(gpio_num_t tx_gpio_num, gpio_num_t rx_gpio_num, uint32_t brp,
                   uint8_t tseg_1, uint8_t tseg_2, uint8_t sjw,
                   bool triple_sampling);

    /**
     * @brief Update motor status from buffer
     *
     * @param id      received can id
     * @param data    received can data
     * @param len     received data length
     * @return true   motor status updated
     * @return false  motor status not updated
     */
    bool updateMotorStatus(unsigned long id, const uint8_t *data,
                           unsigned long len);

    /**
     * @brief Set motor mode
     *
     * @param motor_id   motor id
     * @param mode       motor mode
     * @return esp_err_t
     */
    esp_err_t setMotorMode(uint8_t motor_id, uint8_t mode);

    /**
     * @brief change motor id
     *
     * @param motor_id   motor id
     * @param target_motor_id target motor id
     * @return esp_err_t
     */
    esp_err_t changeMotorId(uint8_t motor_id, uint8_t next_motor_id);

private:
    uint8_t master_can_id_;          //!< master can id
    uint8_t target_can_id_;          //!< target can id
    twai_general_config_t g_config;  //!< general config
    twai_timing_config_t t_config;   //!< timing config
    twai_filter_config_t f_config;   //!< filter config
    twai_message_t tx_message;       //!< tx message
    twai_message_t rx_message;       //!< rx message
    // set TAG to "CybergearDriver"
    static const char *TAG;  //!< tag
    // SemaphoreHandle_t mutex;         //!< mutex
    // QueueHandle_t tx_queue;          //!< tx queue
    // QueueHandle_t rx_queue;          //!< rx queue

    /**
     * @brief Transmit message
     *
     * @param message   message
     * @return esp_err_t
     */
    esp_err_t transmitMessage(twai_message_t *message);

    /**
     * @brief Receive message
     *
     * @param message   message
     * @return esp_err_t
     */
    esp_err_t receiveMessage(twai_message_t &message);

    /**
     * @brief Send command
     *
     * @param cmd   command
     * @param data  data
     * @return esp_err_t
     */
    // esp_err_t sendCommand(uint8_t cmd, uint8_t *data);
    esp_err_t sendCommand(uint8_t can_id, uint8_t cmd_id, uint16_t option,
                          uint8_t len, uint8_t data[]);

    /**
     * @brief Receive response
     *
     * @param cmd   command
     * @param data  data
     * @return esp_err_t
     */
    esp_err_t receiveResponse(uint8_t cmd, uint8_t *data);

    /**
     * @brief Set motor parameter
     *
     * @param motor_id   motor id
     * @param addr       address
     * @param value      value
     * @return esp_err_t
     */
    esp_err_t setMotorParameter(uint8_t motor_id, uint16_t addr, float value);

    /**
     * @brief Get motor parameter
     *
     * @param motor_id   motor id
     * @param addr       address
     * @param value      value
     * @return esp_err_t
     */
    esp_err_t getMotorParameter(uint8_t motor_id, uint16_t addr, float *value);

    /**
     * @brief Get motor status
     *
     * @param motor_id   motor id
     * @param status     motor status
     * @return esp
     * @return esp_err_t
     */
    esp_err_t getMotorStatus(uint8_t motor_id, MotorStatus *status);
};