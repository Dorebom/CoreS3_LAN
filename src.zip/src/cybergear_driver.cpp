#include "cybergear_driver.hpp"

#include <string.h>

#include "esp_err.h"
#include "esp_log.h"

const char* CybergearDriver::TAG = "CybergearDriver";

CybergearDriver::CybergearDriver() : master_can_id_(0x00) {
}

CybergearDriver::CybergearDriver(uint8_t master_can_id)
    : master_can_id_(master_can_id) {
}

CybergearDriver::~CybergearDriver() {
}

esp_err_t CybergearDriver::init(gpio_num_t tx_gpio_num, gpio_num_t rx_gpio_num,
                                uint32_t brp, uint8_t tseg_1, uint8_t tseg_2,
                                uint8_t sjw, bool triple_sampling) {
    twai_general_config_t g_config =
        TWAI_GENERAL_CONFIG_DEFAULT(tx_gpio_num, rx_gpio_num, TWAI_MODE_NORMAL);
    twai_timing_config_t t_config = {
        .brp = brp,
        .tseg_1 = tseg_1,
        .tseg_2 = tseg_2,
        .sjw = sjw,
        .triple_sampling = triple_sampling,
    };
    twai_filter_config_t f_config = TWAI_FILTER_CONFIG_ACCEPT_ALL();

    esp_err_t err = twai_driver_install(&g_config, &t_config, &f_config);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "twai_driver_install failed (%s)", esp_err_to_name(err));
        return err;
    }

    err = twai_start();
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "twai_start failed (%s)", esp_err_to_name(err));
        return err;
    }

    return ESP_OK;
}

bool CybergearDriver::updateMotorStatus(unsigned long id, const uint8_t* data,
                                        unsigned long len) {
    if (id == master_can_id_) {
        // update motor status
        return true;
    }

    return false;
}

esp_err_t CybergearDriver::setMotorMode(uint8_t motor_id, uint8_t mode) {
    // set class variable
    uint8_t data[8] = {0x00};
    data[0] = ADDR_RUN_MODE & 0x00FF;
    data[1] = ADDR_RUN_MODE >> 8;
    data[4] = mode;
    return sendCommand(motor_id, CMD_RAM_WRITE, master_can_id_, 8, data);
}

esp_err_t CybergearDriver::changeMotorId(uint8_t motor_id,
                                         uint8_t next_motor_id) {
    uint8_t data[8] = {0x00};
    uint16_t option = next_motor_id << 8 | master_can_id_;
    sendCommand(motor_id, CMD_CHANGE_CAN_ID, option, 8, data);

    return transmitMessage(&tx_message);
}

esp_err_t CybergearDriver::sendCommand(uint8_t can_id, uint8_t cmd_id,
                                       uint16_t option, uint8_t len,
                                       uint8_t send_data[]) {
    uint32_t id = 0x80000000 | cmd_id << 24 | option << 8 | can_id;
    twai_message_t tx_message = {.identifier = id, .data_length_code = len};
    memcpy(tx_message.data, send_data, len);
    return transmitMessage(&tx_message);
}

esp_err_t CybergearDriver::receiveResponse(uint8_t cmd, uint8_t* data) {
    twai_message_t rx_message;
    esp_err_t err = receiveMessage(rx_message);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "receiveMessage failed (%s)", esp_err_to_name(err));
        return err;
    }
    if ((rx_message.identifier & 0x80000000) == 0) {
        ESP_LOGE(TAG, "invalid response");
        return ESP_FAIL;
    }
    if ((rx_message.identifier & 0x00FF0000) >> 16 != cmd) {
        ESP_LOGE(TAG, "invalid command");
        return ESP_FAIL;
    }
    memcpy(data, rx_message.data, rx_message.data_length_code);
    return ESP_OK;
}

esp_err_t CybergearDriver::transmitMessage(twai_message_t* message) {
    esp_err_t err = twai_transmit(message, portMAX_DELAY);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "twai_transmit failed (%s)", esp_err_to_name(err));
        return err;
    }
    return ESP_OK;
}

esp_err_t CybergearDriver::receiveMessage(twai_message_t& message) {
    esp_err_t err = twai_receive(&message, portMAX_DELAY);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "twai_receive failed (%s)", esp_err_to_name(err));
        return err;
    }
    return ESP_OK;
}
