/**
 * @file Slave.ino
 * @author SeanKwok (shaoxiang@m5stack.com)
 * @brief Unit Mini CAN Test Master
 * @version 0.1
 * @date 2024-02-01
 *
 *
 * @Hardwares: M5CoreS3 + Unit Mini CAN
 * @Platform Version: Arduino M5Stack Board Manager v2.0.9
 * @Dependent Library:
 * M5GFX: https://github.com/m5stack/M5GFX
 * M5Unified: https://github.com/m5stack/M5Unified
 * M5CoreS3: https://github.com/m5stack/M5CoreS3
 */

#include <M5CoreS3.h>
#include <stdio.h>
#include <stdlib.h>

#include "driver/twai.h"
#include "esp_err.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include "robot_controller.hpp"

M5Canvas canvas(&CoreS3.Display);

/* --------------------- Definitions and static variables ------------------ */

#define TX_TASK_PRIO 8               // Receiving task priority
#define TX_GPIO_NUM  gpio_num_t(17)  // old 9
#define RX_GPIO_NUM  gpio_num_t(18)  // old 8

static const twai_general_config_t g_config =
    TWAI_GENERAL_CONFIG_DEFAULT(TX_GPIO_NUM, RX_GPIO_NUM, TWAI_MODE_NORMAL);
static const twai_timing_config_t t_config = TWAI_TIMING_CONFIG_1MBITS();
static const twai_filter_config_t f_config = TWAI_FILTER_CONFIG_ACCEPT_ALL();

#define ID_SLAVE_1 0x0B1

static const twai_message_t slave_1_on = {.identifier = ID_SLAVE_1,
                                          .data_length_code = 8,
                                          .data = {1, 2, 3, 4, 5, 6, 7, 8}};

static const twai_message_t slave_1_off = {.identifier = ID_SLAVE_1,
                                           .data_length_code = 8,
                                           .data = {0, 0, 0, 0, 0, 0, 0, 0}};

RobotController CoreS3Controller(0x00);

static void twai_transmit_task(void *arg) {
    while (1) {
        // CoreS3Controller.process_recv_can_packet();

        CoreS3Controller.displayStatus();

        CoreS3Controller.checkAlerts();

        vTaskDelay(pdMS_TO_TICKS(1000));
    }
    vTaskDelete(NULL);
}

void setup() {
    auto cfg = M5.config();
    CoreS3.begin(cfg);
    USBSerial.begin(115200);

    canvas.setColorDepth(1);  // mono color
    canvas.createSprite(CoreS3.Display.width(), CoreS3.Display.height());
    canvas.setPaletteColor(1, GREEN);
    canvas.setTextScroll(true);
    canvas.println("CAN Master");
    canvas.pushSprite(0, 0);

    CoreS3Controller.setCanvas(&canvas);

    // ESP_ERROR_CHECK(twai_driver_install(&g_config, &t_config, &f_config));
    // USBSerial.println("Driver installed");
    // ESP_ERROR_CHECK(twai_start());
    // USBSerial.println("Driver started");

    CoreS3Controller.initTwai(TX_GPIO_NUM, RX_GPIO_NUM);
    CoreS3Controller.initMotor();

    xTaskCreatePinnedToCore(twai_transmit_task, "twai_transmit_task", 4096,
                            NULL, TX_TASK_PRIO, NULL, tskNO_AFFINITY);
}

void loop() {
}