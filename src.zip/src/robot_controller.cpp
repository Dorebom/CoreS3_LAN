#include "robot_controller.hpp"

// #include <stdint.h>
// #include <string.h>
#include <cstring>  // Include the header file for memcpy

#include "esp_err.h"
#include "esp_log.h"

const char* RobotController::TAG = "RobotController";

RobotController::RobotController() : master_can_id_(0x00), display_cnt_(0) {
}
RobotController::RobotController(uint8_t master_can_id)
    : master_can_id_(master_can_id), display_cnt_(0) {
    initMotor();
}
RobotController::~RobotController() {
}

void RobotController::setCanvas(M5Canvas* canvas) {
    canvas_ = canvas;
}

void RobotController::initMotorConfigs() {
    motor_configs_[0x01] = {0x10, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    // motor_configs_[0x02] = {0x11, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    //  motor_configs_[0x03] = {0x03, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    //  motor_configs_[0x04] = {0x04, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    //  motor_configs_[0x05] = {0x05, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    //  motor_configs_[0x06] = {0x06, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    //  motor_configs_[0x07] = {0x07, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    //  motor_configs_[0x08] = {0x08, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    //  motor_configs_[0x09] = {0x09, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    //  motor_configs_[0x0A] = {0x0A, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    //  motor_configs_[0x0B] = {0x0B, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    //  motor_configs_[0x0C] = {
}

void RobotController::initMotorDriver() {
    motor_driver_ = XiaomiCyberGearDriver(master_can_id_);
    for (auto& motor : motor_configs_) {
        motor_driver_.init_motor(motor.second.id, MODE_POSITION);
    }
    // enable motor
    for (auto& motor : motor_configs_) {
        motor_driver_.enable_motor(motor.second.id);
    }
}

void RobotController::initMotorStatus() {
    for (auto& motor : motor_configs_) {
        motor_status_[motor.first] = MotorStatus();
        motor_status_[motor.first].setMasterCanId(master_can_id_);
        motor_status_[motor.first].setMotorCanId(motor.second.id);
    }
}
void RobotController::initTwai(uint8_t rx_pin, uint8_t tx_pin) {
    motor_driver_.init_twai(rx_pin, tx_pin, /*serial_debug=*/false);
}

void RobotController::initMotor() {
    initMotorConfigs();
    initMotorDriver();
    initMotorStatus();
}

void RobotController::checkAlerts() {
    // Check if alert happened
    uint32_t alerts_triggered;
    twai_read_alerts(&alerts_triggered, pdMS_TO_TICKS(POLLING_RATE_MS));
    twai_status_info_t twai_status;
    twai_get_status_info(&twai_status);

    // Handle alerts
    if (alerts_triggered & TWAI_ALERT_ERR_PASS) {
        USBSerial.println("Alert: TWAI controller has become error passive.");
    }
    if (alerts_triggered & TWAI_ALERT_BUS_ERROR) {
        USBSerial.println(
            "Alert: A (Bit, Stuff, CRC, Form, ACK) error has occurred on the "
            "bus.");
        USBSerial.printf("Bus error count: %d\n", twai_status.bus_error_count);
    }
    if (alerts_triggered & TWAI_ALERT_TX_FAILED) {
        USBSerial.println("Alert: The Transmission failed.");
        USBSerial.printf("TX buffered: %d\t", twai_status.msgs_to_tx);
        USBSerial.printf("TX error: %d\t", twai_status.tx_error_counter);
        USBSerial.printf("TX failed: %d\n", twai_status.tx_failed_count);
    }
    if (alerts_triggered & TWAI_ALERT_TX_SUCCESS) {
        USBSerial.println("Alert: The Transmission was successful.");
        USBSerial.printf("TX buffered: %d\t", twai_status.msgs_to_tx);
    }

    // Check if message is received
    if (alerts_triggered & TWAI_ALERT_RX_DATA) {
        twai_message_t message;
        while (twai_receive(&message, 0) == ESP_OK) {
            handle_rx_message(message);
        }
    }
}

void RobotController::handle_rx_message(twai_message_t& message) {
    if (((message.identifier & 0xFF00) >> 8) == 0x10) {
        // process_message(message);
        motor_status_[0x01].updateStatus(0x10, message.data);
        motor_driver_.process_message(message);
    }

    // print received message
    // Serial.printf("ID: %x\nByte:", message.identifier);
    // if (!(message.rtr)) {
    //   for (int i = 0; i < message.data_length_code; i++) {
    //     Serial.printf(" %d = %02x,", i, message.data[i]);
    //   }
    //   Serial.println("");
    // }
}

esp_err_t RobotController::process_recv_can_packet() {
    bool is_updated = false;
    twai_message_t rx_message;

    esp_err_t err = ESP_OK;

    delay(10000);
    while (err == ESP_OK) {
        // check: if the message is for the master
        canvas_->clear();
        canvas_->setCursor(0, 0);
        canvas_->printf("FIRST...\n");
        canvas_->pushSprite(&CoreS3.Display, 0, 0);

        err = receiveMessage(rx_message);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "receiveMessage failed (%s)", esp_err_to_name(err));
            return err;
        }
        /*
        if ((rx_message.identifier & 0x00FF) != master_can_id_) {
            canvas_->clear();
            canvas_->setCursor(0, 0);
            canvas_->printf("CAN ID11: 0x%02X\n",
                            rx_message.identifier & 0x00FF);
            canvas_->pushSprite(&CoreS3.Display, 0, 0);
            continue;
        }
        uint8_t can_id = (rx_message.identifier & 0xFF00) >> 8;
        if (motor_status_.find(can_id) == motor_status_.end()) {
            canvas_->clear();
            canvas_->setCursor(0, 0);
            canvas_->printf("CAN ID22: 0x%02X\n", can_id);
            canvas_->pushSprite(&CoreS3.Display, 0, 0);
            continue;
        }

        // update motor status
        is_updated =
            motor_status_[can_id].updateStatus(can_id, rx_message.data);
        if (is_updated) {
            ESP_LOGI(TAG, "update motor status");
        }
        */
        canvas_->clear();
        canvas_->setCursor(0, 0);
        canvas_->printf("CONTINUE...\n");
        canvas_->pushSprite(&CoreS3.Display, 0, 0);
    }

    canvas_->clear();
    canvas_->setCursor(0, 0);
    canvas_->printf("DONE...\n");
    canvas_->pushSprite(&CoreS3.Display, 0, 0);

    return esp_err_t();
}

void RobotController::getMotorStatus() {
}

/*
 * CAN FUNCTIONS
 * - init
 * - transmitMessage
 * - receiveMessage
 */

esp_err_t RobotController::init(gpio_num_t tx_gpio_num, gpio_num_t rx_gpio_num,
                                uint32_t brp, uint8_t tseg_1, uint8_t tseg_2,
                                uint8_t sjw, bool triple_sampling) {
    twai_general_config_t g_config =
        TWAI_GENERAL_CONFIG_DEFAULT(tx_gpio_num, rx_gpio_num, TWAI_MODE_NORMAL);
    twai_timing_config_t t_config = {
        .brp = brp,
        .tseg_1 = tseg_1,
        .tseg_2 = tseg_2,
        .sjw = sjw,
        .triple_sampling = triple_sampling,
    };
    twai_filter_config_t f_config = TWAI_FILTER_CONFIG_ACCEPT_ALL();

    esp_err_t err = twai_driver_install(&g_config, &t_config, &f_config);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "twai_driver_install failed (%s)", esp_err_to_name(err));
        return err;
    }

    err = twai_start();
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "twai_start failed (%s)", esp_err_to_name(err));
        return err;
    }

    return ESP_OK;
}

esp_err_t RobotController::transmitMessage(twai_message_t* message) {
    esp_err_t err = twai_transmit(message, portMAX_DELAY);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "twai_transmit failed (%s)", esp_err_to_name(err));
        return err;
    }
    return ESP_OK;
}

esp_err_t RobotController::receiveMessage(twai_message_t& message) {
    esp_err_t err = twai_receive(&message, portMAX_DELAY);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "twai_receive failed (%s)", esp_err_to_name(err));
        return err;
    }
    return ESP_OK;
}
// END CAN FUNCTIONS

/*
 * MOTOR FUNCTIONS - CybergearDriver -
 * - sendCommand
 * - changeMotorId
 * - setMotorMode
 */

esp_err_t RobotController::sendCommand(uint8_t can_id, uint8_t cmd_id,
                                       uint16_t option, uint8_t len,
                                       uint8_t send_data[]) {
    uint32_t id = 0x80000000 | cmd_id << 24 | option << 8 | can_id;
    twai_message_t tx_message = {.identifier = id, .data_length_code = len};
    std::memcpy(tx_message.data, send_data,
                len);  // Use std::memcpy instead of memcpy
    return transmitMessage(&tx_message);
}

esp_err_t RobotController::changeMotorId(uint8_t motor_id,
                                         uint8_t next_motor_id) {
    uint8_t data[8] = {0x00};
    uint16_t option = next_motor_id << 8 | master_can_id_;
    return sendCommand(motor_id, CMD_CHANGE_CAN_ID, option, 8, data);
}

esp_err_t RobotController::setMotorMode(uint8_t motor_id, uint8_t mode) {
    uint8_t data[8] = {0x00};
    data[0] = ADDR_RUN_MODE & 0x00FF;
    data[1] = ADDR_RUN_MODE >> 8;
    data[4] = mode;
    return sendCommand(motor_id, CMD_RAM_WRITE, master_can_id_, 8, data);
}

// END MOTOR FUNCTIONS

esp_err_t RobotController::receiveResponse(uint8_t cmd, uint8_t* data) {
    twai_message_t rx_message;
    esp_err_t err = receiveMessage(rx_message);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "receiveMessage failed (%s)", esp_err_to_name(err));
        return err;
    }
    if ((rx_message.identifier & 0x80000000) == 0) {
        ESP_LOGE(TAG, "invalid response");
        return ESP_FAIL;
    }
    if ((rx_message.identifier & 0x00FF0000) >> 16 != cmd) {
        ESP_LOGE(TAG, "invalid command");
        return ESP_FAIL;
    }
    memcpy(data, rx_message.data, rx_message.data_length_code);
    return ESP_OK;
}

void RobotController::displayStatus() {
    canvas_->clear();
    canvas_->setCursor(0, 0);
    canvas_->printf("CAN Master(CAN ID: 0x%02X)\n", master_can_id_);
    canvas_->printf("Motor Status: %d\n", display_cnt_);
    for (auto& motor : motor_status_) {
        canvas_->printf(
            "No.0x%02X\t: CAN_ID_0x%02X,\t POS_%.2f,\t VEL_%.2f,\t "
            "EFT_%.2f\t\n",
            motor.first, motor.second.motor_can_id, motor.second.position,
            motor.second.velocity, motor.second.effort);
    }

    canvas_->pushSprite(&CoreS3.Display, 0, 0);
    display_cnt_++;
    /*
    canvas.setCursor(0, 0);
    canvas.printf("CAN Master\n");
    canvas.printf("Master CAN ID: 0x%02X\n", master_can_id_);
    canvas.printf("Motor Status\n");
    for (auto& motor : motor_drivers_) {
        canvas.printf("CAN ID: 0x%02X\n", motor.first);
        // canvas.printf("Status: %s\n", motor.second.getStatus());
    }
    canvas.pushSprite(0, 0);
    */
}
